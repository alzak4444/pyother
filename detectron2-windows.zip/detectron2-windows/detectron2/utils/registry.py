# Copyright (c) Facebook, Inc. and its affiliates.

# Keep this module for backward compatibility.
from fvcore.common.registry import Registry  # noqa

__all__ = ["Registry"]
